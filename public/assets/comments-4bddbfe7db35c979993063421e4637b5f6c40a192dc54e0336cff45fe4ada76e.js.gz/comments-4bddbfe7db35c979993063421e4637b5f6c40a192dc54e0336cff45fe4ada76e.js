(function() {
	var times = document.querySelectorAll('.comments time');
})()
;
